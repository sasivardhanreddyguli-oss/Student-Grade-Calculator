document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("gradeForm");
    if (!form) return;

    form.addEventListener("submit", (event) => {
        const name = document.getElementById("studentName").value.trim();
        const markFields = ["subject1", "subject2", "subject3"];
        if (!name) {
            event.preventDefault();
            alert("Please enter the student's name.");
            return;
        }
        for (const id of markFields) {
            const field = document.getElementById(id);
            const value = Number(field.value);
            if (field.value === "" || !Number.isFinite(value) || value < 0 || value > 100) {
                event.preventDefault();
                alert("Please enter a valid mark between 0 and 100 for every subject.");
                field.focus();
                return;
            }
        }
    });
});
